import React from "react";

const SuperAdminDashboard = () => {
    return(<div>
        <h1>Hyyyy</h1>
    </div>);
}

export default SuperAdminDashboard;