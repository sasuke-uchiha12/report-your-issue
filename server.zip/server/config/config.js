module.exports = {
    jwtSecret: 'estateoffice'
  };
  